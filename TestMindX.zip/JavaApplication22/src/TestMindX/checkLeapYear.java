/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestMindX;

import java.util.Scanner;

/**
 *
 * @author tienm
 */
public class checkLeapYear {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a year: ");
        int year = sc.nextInt();
        if(year%4==0){
            System.out.println(year + " is leap year");
        }else{
            System.out.println(year + " isn't leap year");
        }
    }
}
