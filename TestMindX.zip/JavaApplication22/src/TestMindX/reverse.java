/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestMindX;

import java.util.Scanner;

/**
 *
 * @author tienm
 */
public class reverse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sequence: ");
        String sequence = sc.nextLine();
        String result = "";
        for(int i = sequence.length()-1; i>= 0;i--){
            result = result + sequence.charAt(i);
        }
        System.out.println(result);
    }
}
