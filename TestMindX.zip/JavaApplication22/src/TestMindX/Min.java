/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestMindX;

/**
 *
 * @author tienm
 */
public class Min {

    public static int Min(int[] A, int number) {
        
        if (number == 0) {
            return -1;
        }
        if (number == 1) {
            return A[0];
        } else {
            if (A[number - 1] < Min(A, number - 1)) {
                return A[number - 1];
            } else {
                return Min(A, number - 1);
            }
        }
    }
}
