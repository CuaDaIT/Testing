/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestMindX;

import java.util.Scanner;

/**
 *
 * @author tienm
 */
public class CountNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        double number = sc.nextDouble();
        int count = 1;
        
        while(number/10>1){
            count++;
            number /= 10;
        }
        System.out.println("This number has "+count+" digit");
    }
}
