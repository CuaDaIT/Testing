/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestMindX;

import java.util.Scanner;

/**
 *
 * @author tienm
 */
public class Fibonaci {

    public static int fibo(int number) {
        if (number == 0) {
            return 0;
        } else if (number == 1) {
            return 1;
        }
        return fibo(number - 1) + fibo(number - 2);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter positon of number in fibonaci: ");
        int position = sc.nextInt();
        System.out.println(fibo(position));
    }
}
