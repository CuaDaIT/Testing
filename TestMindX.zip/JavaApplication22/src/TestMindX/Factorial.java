/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestMindX;

import java.util.Scanner;

/**
 *
 * @author tienm
 */
public class Factorial {
    public static int calFactorial(int number){
        if(number == 1){
            return 1;
        }
        return number*calFactorial(number-1);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        System.out.println(calFactorial(sc.nextInt()));
    }
}
