/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestMindX;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author tienm
 */
public class AddToBegin {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> sequence = new ArrayList<>();
        sequence.add(1);
        sequence.add(5);
        sequence.add(-9);
        sequence.add(3);
        System.out.println("Hi there, this is our sequence: ");
        for (int i = 0; i < sequence.size(); i++) {
            System.out.print(sequence.get(i) + " ");
        }
        System.out.print("\nWhat do you you want to add: ");
        int number = sc.nextInt();
        sequence.add(number);

        for (int i = sequence.size() - 1; i >= 0; i--) {
            if (i == 0) {
                sequence.set(i, number);
                break;
            }
            sequence.set(i, sequence.get(i - 1));
        }
        System.out.println("This is our new sequence: ");
        for (int i = 0; i < sequence.size(); i++) {
            System.out.print(sequence.get(i) + " ");
        }
    }
}
